﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CNPM_FinalProject
{
    public partial class Form4 : Form
    {
        private static string accountant_Name = "";
        private static string receiptID = "";
        private static string receiptID2 = "";
        private static string itemID = "";
        private static string warehouseID = "";
        private static string item_Quantity = "";
        private static DateTime date;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
           
            

        }
    }
}
