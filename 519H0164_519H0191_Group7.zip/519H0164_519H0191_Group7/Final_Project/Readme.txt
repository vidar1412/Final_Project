--------------FILE STRUCTURE--------------------------
1. In the activity&sequence folder we have all the activity and sequence diagrams as well as visual paradigm file
2. In the Boostrap_Studio folder we have all the files created by boostrap studio during UI development.
3. In the Chart folder we have flowhchart diagram and Organaization chart (we didn't include this in report file)
4. In the Class Diagram folder contains all the class diagrams related to this project
5. In the ERD_Diagram folder contains all the SQL files (ERD, .sql file) related to this project
6. In the sourceCode folder contains 2 folders. 1 is CNPM_FinalProject, this is the folder containing winform. 
						2 is the website folder containing the website's UI part.
7. In the UseCaseDiagram folder contains all files related to Use Case Model.
8. The Report.docx is our team's project report file. Contains all the information related to the project.

------------------------CONTACT INFORMATION----------------------------------------
TDTU email: 519H0164@student.tdtu.edu.vn
	    519H0191@student.tdtu.edu.vn
Personal email: vidar1412@gmail.com
Phone number: 0904586408

-----------------------Link DEMO----------------------------------------------------
https://youtu.be/nV35kXxg75Y   (already included in Report.docx, Chapter 6)
------------------------------------------------------------------------------------

This file is created for the purpose of helping examiners better understand the information of the project. 
GROUP 7 sincerely thank you